<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Website Portal Desa Kertamukti Copyright 2025</p> Repost By : KKN-PM Universitas Cipasung 2025</a>
  </div>